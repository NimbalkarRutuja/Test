let p=fetch('data.json')
.then((response)=>{
    return response.json()
})
.then((display)=>{
    let list=document.querySelector('ul');
    display.forEach(display1=>{
        list.insertAdjacentHTML('beforeend',`<li>${display1.ID} <br/>${display1.ImageUrl}<br/>${display1.Name}<br/>${display1.ShortDesc}</li>`)
    })
})